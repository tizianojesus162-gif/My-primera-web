#Lista de los libros
libros = [
    {"isbn": "978-001", "titulo": "Python desde cero", "autor": "Laura Gomez", "disponible": True},
    {"isbn": "978-002", "titulo": "Programacion basica", "autor": "Carlos Perez", "disponible": False},
    {"isbn": "978-003", "titulo": "Bases de datos", "autor": "Ana Torres", "disponible": True},
    {"isbn": "978-004", "titulo": "Algoritmos", "autor": "Mario Lopez", "disponible": True},
    {"isbn": "978-005", "titulo": "POO con Python", "autor": "Sofia Diaz", "disponible": False}
]
print("--- Busqueda corregida ---")
isbn_buscado = input("Ingrese el ISBN a buscar: ")
libro_encontrado = False
for libro in libros:
    if libro["isbn"] == isbn_buscado:
        print("ISBN:", libro["isbn"])
        print("Titulo:", libro["titulo"])
        print("Autor:", libro["autor"])
        print("Disponible:", libro["disponible"])
        libro_encontrado = True
        break
if not libro_encontrado:
    print("Libro no encontrado")