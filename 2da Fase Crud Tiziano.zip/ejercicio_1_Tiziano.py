# Se muestra la lista de equipos del laboratorio
equipos = [
    {"inventario": 1, "tipo": "Netbook", "marca": "Lenovo", "estado": "Disponible", "año": 2022},
    {"inventario": 2, "tipo": "PC", "marca": "HP", "estado": "En reparación", "año": 2021},
    {"inventario": 3, "tipo": "Netbook", "marca": "Dell", "estado": "Disponible", "año": 2023},
    {"inventario": 4, "tipo": "PC", "marca": "Lenovo", "estado": "Baja", "año": 2020},
    {"inventario": 5, "tipo": "Netbook", "marca": "HP", "estado": "Disponible", "año": 2024},
    {"inventario": 6, "tipo": "PC", "marca": "Dell", "estado": "Disponible", "año": 2022},
    {"inventario": 7, "tipo": "Netbook", "marca": "Lenovo", "estado": "En reparación", "año": 2023},
    {"inventario": 8, "tipo": "PC", "marca": "HP", "estado": "Baja", "año": 2019}
]
# Ingresar año minimo
año_minimo = int(input("Ingrese el año minimo: "))
# Contar los equipos encontrados
cantidad = 0
# Se recorre la lista una sola vez
for equipo in equipos:
    if equipo["estado"] == "Disponible" and equipo["año"] >= año_minimo:
        print("Inventario:", equipo["inventario"])
        print("Tipo de computadora:", equipo["tipo"])
        print("Marca de la computadora:", equipo["marca"])
        print("Estado en el que se encuentra:", equipo["estado"])
        print("Año:", equipo["año"])
        print("-------------------")
        cantidad += 1
print("Cantidad de equipos que cumplen:", cantidad)
if cantidad == 0:
 #Mostrar mensaje si no hay equipos disponibles que cumplan el año indicado
 print("No hay equipos disponibles que cumplan el año indicado.")