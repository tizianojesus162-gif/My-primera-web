#Lista de ordenes de reparacion
ordenes = [
    {"numero": 1001, "cliente": "Juan Perez", "equipo": "Notebook Lenovo", "falla": "No enciende", "estado": "Pendiente", "costo": 45000},
    {"numero": 1002, "cliente": "Maria Lopez", "equipo": "PC HP", "falla": "No da imagen", "estado": "En reparacion", "costo": 70000},
    {"numero": 1003, "cliente": "Pedro Gomez", "equipo": "Notebook Dell", "falla": "Teclado", "estado": "Finalizada", "costo": 30000},
    {"numero": 1004, "cliente": "Lucia Diaz", "equipo": "PC Lenovo", "falla": "Disco dañado", "estado": "En reparacion", "costo": 90000},
    {"numero": 1005, "cliente": "Santiago Ruiz", "equipo": "Notebook HP", "falla": "Bateria", "estado": "Pendiente", "costo": 55000},
    {"numero": 1006, "cliente": "Valentina Silva", "equipo": "PC Dell", "falla": "Fuente", "estado": "Finalizada", "costo": 25000},
    {"numero": 1007, "cliente": "Martin Torres", "equipo": "Notebook Asus", "falla": "Pantalla", "estado": "En reparacion", "costo": 120000},
    {"numero": 1008, "cliente": "Camila Fernandez", "equipo": "PC Acer", "falla": "Limpieza", "estado": "Pendiente", "costo": 20000}
]
def mostrar_orden(orden):
    print("Numero:", orden["numero"])
    print("Cliente:", orden["cliente"])
    print("Equipo:", orden["equipo"])
    print("Falla:", orden["falla"])
    print("Estado:", orden["estado"])
    print("Costo estimado:", orden["costo"])
    print("-------------------")
def buscar_orden(numero):
    for orden in ordenes:
        if orden["numero"] == numero:
            return orden
    return None
def filtrar_por_estado(estado):
    encontrados = 0
    for orden in ordenes:
        if orden["estado"].lower() == estado.lower():
            mostrar_orden(orden)
            encontrados += 1
    if encontrados == 0:
        print("No existen ordenes con ese estado.")
def filtrar_por_costo(limite):
    encontrados = 0
    for orden in ordenes:
        if orden["costo"] <= limite:
            mostrar_orden(orden)
            encontrados += 1
    if encontrados == 0:
        print("No existen ordenes dentro de ese limite de costo.")
def mostrar_todas():
    for orden in ordenes:
        mostrar_orden(orden)
while True:
    print("\n===== MENU DE CONSULTAS =====")
    print("1. Buscar orden por numero")
    print("2. Filtrar por estado")
    print("3. Filtrar por costo")
    print("4. Mostrar todas las ordenes")
    print("5. Salir")
    opcion = input("Seleccione una opcion: ")
    if opcion == "1":
        numero = int(input("Ingrese el numero de orden: "))
        orden = buscar_orden(numero)
        if orden is None:
            print("No hay una orden con ese numero. Inserte un numero valido.")
        else:
            mostrar_orden(orden)
    elif opcion == "2":
        estado = input("Ingrese el estado (Pendiente, En reparacion o Finalizada): ")
        filtrar_por_estado(estado)
    elif opcion == "3":
        limite = float(input("Ingrese el costo maximo: "))
        filtrar_por_costo(limite)
    elif opcion == "4":
        mostrar_todas()
    elif opcion == "5":
        print("Programa finalizado.")
        break
    else:
        print("Opcion no valida.")