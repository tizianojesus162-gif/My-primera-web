#Lista de productos
repuestos = [
    {"codigo": 1, "descripcion": "SSD Kingston 480 GB", "categoria": "Almacenamiento", "marca": "Kingston", "precio": 45000, "stock": 4},
    {"codigo": 2, "descripcion": "SSD Crucial 1 TB", "categoria": "Almacenamiento", "marca": "Crucial", "precio": 70000, "stock": 0},
    {"codigo": 3, "descripcion": "Memoria RAM 8 GB", "categoria": "Memoria", "marca": "Kingston", "precio": 30000, "stock": 6},
    {"codigo": 4, "descripcion": "Fuente 600W", "categoria": "Fuente", "marca": "Thermaltake", "precio": 65000, "stock": 2},
    {"codigo": 5, "descripcion": "Placa de video GTX 1660", "categoria": "Video", "marca": "MSI", "precio": 250000, "stock": 1},
    {"codigo": 6, "descripcion": "Cooler para procesador", "categoria": "Refrigeracion", "marca": "DeepCool", "precio": 28000, "stock": 5},
    {"codigo": 7, "descripcion": "Teclado USB", "categoria": "Perifericos", "marca": "Logitech", "precio": 18000, "stock": 8},
    {"codigo": 8, "descripcion": "Cable SATA", "categoria": "Cables", "marca": "Generico", "precio": 5000, "stock": 0}
]
busqueda = input("Ingrese una descripcion o parte: ").lower()
coincidencias = 0
disponibles = 0
for repuesto in repuestos:
    if busqueda in repuesto["descripcion"].lower():
        print("Codigo:", repuesto["codigo"])
        print("Descripcion del producto:", repuesto["descripcion"])
        print("Categoria del producto:", repuesto["categoria"])
        print("Marca del producto:", repuesto["marca"])
        print("Precio:", repuesto["precio"])
        print("Stock:", repuesto["stock"])
        print("-------------------")
        coincidencias += 1
        if repuesto["stock"] > 0:
            print("Disponible: Si")
            disponibles += 1
        else:
            print("Disponible: NO")
print("Cantidad total de coincidencias:", coincidencias)
print("Cantidad disponibles:", disponibles)
if coincidencias == 0:
    print("La busqueda no produjo resultados.")