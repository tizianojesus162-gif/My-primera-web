#lista de alumnos
alumnos = [
    {"nombre": "Ana", "curso": "5A", "promedio": 8.5, "trabajos": 6},
    {"nombre": "Bruno", "curso": "5A", "promedio": 7.2, "trabajos": 5},
    {"nombre": "Carla", "curso": "5B", "promedio": 9.1, "trabajos": 7},
    {"nombre": "Diego", "curso": "5B", "promedio": 6.8, "trabajos": 4},
    {"nombre": "Elena", "curso": "5A", "promedio": 8.9, "trabajos": 8},
    {"nombre": "Facundo", "curso": "5C", "promedio": 7.5, "trabajos": 6},
    {"nombre": "Gabriela", "curso": "5C", "promedio": 9.4, "trabajos": 9},
    {"nombre": "Hugo", "curso": "5B", "promedio": 6.5, "trabajos": 3},
    {"nombre": "Irene", "curso": "5A", "promedio": 8.1, "trabajos": 7},
    {"nombre": "Joaquin", "curso": "5C", "promedio": 9.0, "trabajos": 8}
]
promedio_minimo = float(input("Ingrese el promedio minimo requerido: "))
trabajos_minimos = int(input("Ingrese la cantidad minima de trabajos entregados: "))
cumplen = 0
no_cumplen = 0
mejor_alumno = None
mejor_promedio = 0
for alumno in alumnos:
    if alumno["promedio"] >= promedio_minimo and alumno["trabajos"] >= trabajos_minimos:
        print("Nombre:", alumno["nombre"])
        print("Curso:", alumno["curso"])
        print("Promedio:", alumno["promedio"])
        print("Trabajos entregados:", alumno["trabajos"])
        print("-------------------")
        cumplen += 1
        # Se busca el promedio mas alto mediante recorrido y comparacion.
        if mejor_alumno is None or alumno["promedio"] > mejor_promedio:
            mejor_alumno = alumno
            mejor_promedio = alumno["promedio"]
    else:
        no_cumplen += 1
print("Cantidad de alumnos que cumplen:", cumplen)
print("Cantidad de alumnos que no cumplen:", no_cumplen)
if cumplen == 0:
    print("Ningun alumno cumple ambos criterios.")
else:
    print("Alumno con el promedio mas alto entre los que cumplen:")
    print("Nombre:", mejor_alumno["nombre"])
    print("Promedio:", mejor_alumno["promedio"])