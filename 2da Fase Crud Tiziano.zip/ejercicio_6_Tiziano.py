class DispositivoRed:
    def __init__(self, codigo, tipo, marca, velocidad_mbps, precio, stock):
        self.codigo = codigo
        self.tipo = tipo
        self.marca = marca
        self.velocidad_mbps = velocidad_mbps
        self.precio = precio
        self.stock = stock
    def mostrar_datos(self):
        print("Codigo:", self.codigo)
        print("Tipo:", self.tipo)
        print("Marca:", self.marca)
        print("Velocidad (Mbps):", self.velocidad_mbps)
        print("Precio:", self.precio)
        print("Stock:", self.stock)
        print("-------------------")
    def hay_stock(self):
        return self.stock > 0
dispositivos = [
    DispositivoRed("R001", "Router", "TP-Link", 1200, 85000, 4),
    DispositivoRed("S001", "Switch", "D-Link", 1000, 65000, 6),
    DispositivoRed("A001", "Access Point", "Ubiquiti", 1200, 110000, 2),
    DispositivoRed("R002", "Router", "MikroTik", 3000, 180000, 3),
    DispositivoRed("S002", "Switch", "TP-Link", 100, 35000, 0),
    DispositivoRed("A002", "Access Point", "TP-Link", 300, 55000, 5)
]
def buscar_por_velocidad(velocidad_minima):
    encontrados = 0
    for dispositivo in dispositivos:
        if dispositivo.velocidad_mbps >= velocidad_minima and dispositivo.hay_stock():
            dispositivo.mostrar_datos()
            encontrados += 1
    if encontrados == 0:
        print("No hay dispositivos con esa velocidad minima y con stock.")
def buscar_por_codigo(codigo):
    for dispositivo in dispositivos:
        if dispositivo.codigo.lower() == codigo.lower():
            return dispositivo
    return None
velocidad_minima = float(input("Ingrese la velocidad minima en Mbps: "))
print("Dispositivos que cumplen la velocidad y tienen stock:")
buscar_por_velocidad(velocidad_minima)
codigo = input("Ingrese un codigo para buscar: ")
dispositivo = buscar_por_codigo(codigo)
if dispositivo is None:
    print("No se encontro un dispositivo con ese codigo.")
else:
    print("Dispositivo encontrado:")
    dispositivo.mostrar_datos()
presupuesto_maximo = float(input("Ingrese el presupuesto maximo: "))
print("Dispositivos con stock que no superan el presupuesto:")
encontrados = 0
for dispositivo in dispositivos:
    if dispositivo.hay_stock() and dispositivo.precio <= presupuesto_maximo:
        dispositivo.mostrar_datos()
        encontrados += 1
if encontrados == 0:
    print("No hay dispositivos con stock dentro del presupuesto indicado.")