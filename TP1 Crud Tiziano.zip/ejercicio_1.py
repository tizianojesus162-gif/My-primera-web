# Se crea la lista pero vacia.
alumnos = []
# Pedimos al usuario el nombre del primer alumno.
nombre1 = input("Ingrese el nombre del primer alumno: ")
# Se agrega el primer nombre a la lista.
alumnos.append(nombre1)
# Pedimos al usuario el nombre del segundo alumno.
nombre2 = input("Ingrese el nombre del segundo alumno: ")
# Se agrega el segundo nombre a la lista.
alumnos.append(nombre2)
# Tercer alumno y se sigue la cuenta mientras que se guardan en la lista.
nombre3 = input("Ingrese el nombre del tercer alumno: ")
alumnos.append(nombre3)
nombre4= input("Ingrese el nombre del cuarto alumno: ")
alumnos.append(nombre4)
nombre5= input("Ingrese el nombre del quinto alumno: ")
alumnos.append(nombre5)
# Se muestra el mensaje de la lista junto con los nombres.
print("\nLista de asistencia:")
print(alumnos)