#1- Registrar Alumnos
print("Registrar Alumnos")
nombre= input("Ingrese su Nombre y Apellido: ")
edad= int(input("Ingrese su Edad: "))
nota= float(input("Ingrese su Calificacion final: "))
#2- Operacion CRUD - Create
nuevo_alumno= {
    "nombre": nombre,
    "edad": edad,
    "nota": nota
}
#3- Verificar
print("\n ¡Registro creado con exito!")
print("Revision de estructura de datos: ")
print(nuevo_alumno)