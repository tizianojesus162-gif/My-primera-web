# Se crea el diccionario pero vacío
alumno = {}
# Pedimos datos de usuario
Nombre = input("Ingrese el nombre: ")
Edad = int(input("Ingrese la edad: "))
Curso = input("Ingrese el curso: ")
# Guardamos los datos en el diccionario
alumno["Nombre"] = Nombre
alumno["Edad"] = Edad
alumno["Curso"] = Curso
# Mostramos los perfiles
print("\nPerfiles Actualizados:")
print(alumno)
print("Gracias por usar nuestros servicios.")