# Creamos la lista vacía
alumnos = []
# Empezamos con un bucle infinito
while True:
    # Ingresamos un nombre
    nombre = input(
        "Ingrese el nombre del alumno "
        "(o escriba 'salir' para terminar): "
    )
    # Si quiere salir
    if nombre.lower() == "salir":
        break
    # Creamos la lista con el nombre ya cargado
    alumno = {
        "nombre": nombre
    }
    # Agregamos los datos a la lista
    alumnos.append(alumno)
    print("Alumno registrado correctamente.\n")
# Mostramos la cantidad total
print("\nMatrícula finalizada.")
print("Cantidad de alumnos creados:", len(alumnos))
# Mostrar a los alumnos registrados
print("\nAlumnos registrados:")
for alumno in alumnos:
    print(alumno)